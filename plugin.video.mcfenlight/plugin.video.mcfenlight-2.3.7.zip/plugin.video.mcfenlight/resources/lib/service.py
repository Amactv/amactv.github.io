from xbmc import Monitor
import os
import json
import inspect
from time import time
from threading import Thread
from caches.settings_cache import get_setting, set_setting, sync_settings
from modules import kodi_utils

# --- McFen metrics ---
try:
	from modules import metrics
	metrics.checkin()
	_mcfen_metrics_player = metrics.MetricsPlayer()
except Exception:
	pass
# --- end metrics ---

pause_services_prop = 'mcfenlight.pause_services'
firstrun_update_prop = 'mcfenlight.firstrun_update'
current_skin_prop = 'mcfenlight.current_skin'
trakt_service_string = 'TraktMonitor Service Update %s - %s'
trakt_success_line_dict = {'success': 'Trakt Update Performed', 'no account': '(Unauthorized) Trakt Update Performed'}
update_string = 'Next Update in %s minutes...'

def _resolve_addon_icon():
	choice = get_setting('addon_icon_choice')
	if choice:
		path = os.path.join(kodi_utils.addon_info('path'), choice)
		if os.path.exists(path): return path
	return kodi_utils.translate_path(kodi_utils.addon_info('icon'))

def _resolve_addon_icon_mini():
	choice = get_setting('addon_icon_choice_name')
	if choice:
		path = os.path.join(kodi_utils.addon_info('path'), 'resources', 'media', 'addon_icons', 'minis', choice)
		if os.path.exists(path): return path
	return _resolve_addon_icon()

class SetAddonConstants:
	def run(self):
		kodi_utils.logger('McFenlight', 'SetAddonConstants Service Starting')
		import random
		addon_items = [
			('mcfenlight.playback_key', str(random.randint(1000, 10000))),
			('mcfenlight.addon_version', kodi_utils.addon_info('version')),
			('mcfenlight.addon_path', kodi_utils.addon_info('path')),
			('mcfenlight.addon_profile', kodi_utils.translate_path(kodi_utils.addon_info('profile'))),
			('mcfenlight.addon_icon', _resolve_addon_icon()),
			('mcfenlight.addon_icon_mini', _resolve_addon_icon_mini()),
			('mcfenlight.addon_fanart', kodi_utils.addon_fanart())
					]
		for item in addon_items: kodi_utils.set_property(*item)
		return kodi_utils.logger('McFenlight', 'SetAddonConstants Service Finished')

class DatabaseMaintenance:
	def run(self):
		kodi_utils.logger('McFenlight', 'DatabaseMaintenance Service Starting')
		from caches.base_cache import check_databases_integrity
		check_databases_integrity(silent=True)
		return kodi_utils.logger('McFenlight', 'DatabaseMaintenance Service Finished')

class SyncSettings:
	def run(self):
		kodi_utils.logger('McFenlight', 'SyncSettings Service Starting')
		sync_settings()
		return kodi_utils.logger('McFenlight', 'SyncSettings Service Finished')

class OnUpdateChanges:
	def run(self):
		kodi_utils.logger('McFenlight', 'OnUpdateChanges Service Starting')
		try:
			for method in list(filter(lambda x: x[0] != 'run', inspect.getmembers(OnUpdateChanges, predicate=inspect.isfunction))):
				if not get_setting('mcfenlight.updatechecks.%s' % method[0], 'false') == 'true':
					method[1](self)
					set_setting('updatechecks.%s' % method[0], 'true')
		except: pass
		return kodi_utils.logger('McFenlight', 'OnUpdateChanges Service Finished')

	def fix_trakt_client(self):
		# 2.2.10: repair stale/revoked Trakt app creds left in migrated settings DBs.
		# DB values override addon defaults, so old installs kept calling the API
		# with a dead client_id. Clears dead tokens; user re-authorizes once.
		new_client = 'd670d157485c272e4a9385da4a8b3d1ba1d248ee93a619309ebd7f9cf6a67351'
		new_secret = '7efa8413b83e997632598f39349444dc6b2d64cae668ff0bf1ca38986a4e8aa5'
		if get_setting('mcfenlight.trakt.client', '') == new_client: return
		set_setting('trakt.client', new_client)
		set_setting('trakt.secret', new_secret)
		set_setting('trakt.token', 'empty_setting')
		set_setting('trakt.refresh', 'empty_setting')
		set_setting('trakt.expires', '0')
		set_setting('trakt.user', 'empty_setting')
		kodi_utils.logger('McFenlight', 'OnUpdateChanges - Trakt app credentials repaired, re-authorization required')

	def resync_trakt_watched_2_3_5(self):
		# 2.3.5: since 2026-06-30 Trakt paginates the watched endpoints and drops season data unless extended=progress,
		# so earlier syncs stored only 100 movies and no episodes. Forget the cached activity stamps so the next
		# TraktMonitor sync (started right after this) refetches every watched list once.
		from caches.base_cache import connect_database
		connect_database('trakt_db').execute('DELETE FROM trakt_data WHERE id = ?', ('trakt_get_activity',))
		kodi_utils.logger('McFenlight', 'OnUpdateChanges - forcing full Trakt watched resync')

class RepoSourceMigrate:
	# 2.3.6: the McFen repo moved to https://amactv.github.io/ - repoint any Kodi File Manager source still at the
	# old address so reinstalling from zip keeps working once the old repo is retired. Idempotent and cheap, so it
	# runs every startup (Kodi writes sources.xml back from memory if a source is edited later in the same session).
	def run(self):
		import re
		sources_xml = kodi_utils.translate_path('special://profile/sources.xml')
		if not os.path.exists(sources_xml): return
		with open(sources_xml, 'rb') as f: data = f.read()
		new_data, count = re.subn(rb'(?i)(?:https?://)?mcmoobud\.github\.io/mcfenrepo/?', b'https://amactv.github.io/', data)
		if not count: return
		backup = sources_xml + '.mcfen-bak'
		if not os.path.exists(backup):
			with open(backup, 'wb') as f: f.write(data)
		temp = sources_xml + '.mcfen-tmp'
		with open(temp, 'wb') as f: f.write(new_data)
		os.replace(temp, sources_xml)
		kodi_utils.logger('McFenlight', 'RepoSourceMigrate - repointed %d File Manager source(s) to amactv.github.io' % count)

class CocoScrapersCompat:
	# 2.3.7: Python 3.12 (Linux flatpak Kodi since 2026-10; Kodi 22 later) removed FileFinder.find_module, which CocoScrapers
	# uses to load every provider -> zero providers and an instant 'No Results'. Patch its loader to the importlib equivalent
	# (older Pythons keep the original call). Idempotent; re-applies if a CocoScrapers update restores the original file.
	def run(self):
		init_py = kodi_utils.translate_path('special://home/addons/script.module.cocoscrapers/lib/cocoscrapers/__init__.py')
		if not os.path.exists(init_py): return
		with open(init_py, 'rb') as f: data = f.read()
		old = b'module = loader.find_module(module_name).load_module(module_name)'
		if b"hasattr(loader, 'find_module')" in data or data.count(old) != 1: return
		pos = data.index(old)
		indent = data[data.rfind(b'\n', 0, pos) + 1:pos]
		step = b'\t' if indent.startswith(b'\t') else b'    '
		nl = b'\r\n' if b'\r\n' in data else b'\n'
		new = nl.join([b"if hasattr(loader, 'find_module'): " + old,
			indent + b'else:  # Python 3.12+ removed find_module/load_module (McFen 2.3.7)',
			indent + step + b'import importlib.util, sys',
			indent + step + b'spec = loader.find_spec(module_name)',
			indent + step + b'module = importlib.util.module_from_spec(spec)',
			indent + step + b'sys.modules[module_name] = module',
			indent + step + b'spec.loader.exec_module(module)'])
		temp = init_py + '.mcfen-tmp'
		with open(temp, 'wb') as f: f.write(data.replace(old, new))
		os.replace(temp, init_py)
		kodi_utils.logger('McFenlight', 'CocoScrapersCompat - patched CocoScrapers provider loader for Python 3.12+')

class CustomWindowsPrepare:
	def run(self):
		kodi_utils.logger('McFenlight', 'CustomWindowsPrepare Service Starting')
		from windows.base_window import FontUtils, ExtrasUtils
		monitor, player = kodi_utils.kodi_monitor(), kodi_utils.kodi_player()
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		kodi_utils.clear_property(current_skin_prop)
		ExtrasUtils().run()
		font_utils = FontUtils()
		while not monitor.abortRequested():
			font_utils.execute_custom_fonts()
			wait_for_abort(20)
		try: del monitor
		except: pass
		try: del player
		except: pass
		return kodi_utils.logger('McFenlight', 'CustomWindowsPrepare Service Finished')

class TraktMonitor:
	def run(self):
		kodi_utils.logger('McFenlight', 'TraktMonitor Service Starting')
		from apis.trakt_api import trakt_sync_activities
		from modules.settings import trakt_user_active, trakt_sync_interval
		monitor, player = kodi_utils.kodi_monitor(), kodi_utils.kodi_player()
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		while not monitor.abortRequested():
			while is_playing() or kodi_utils.get_property(pause_services_prop) == 'true': wait_for_abort(10)
			wait_time = 1800
			try:
				sync_interval, wait_time = trakt_sync_interval()
				next_update_string = update_string % sync_interval
				if trakt_user_active: status = trakt_sync_activities()
				else: status = 'no_auth'
				if status == 'failed': kodi_utils.logger('McFenlight', trakt_service_string % ('Failed. Error from Trakt', next_update_string))
				elif status == 'no_auth': kodi_utils.logger('McFenlight', trakt_service_string % ('Not Run. No Current Trakt Account', next_update_string))
				else:
					if status in ('success', 'no account'):
						kodi_utils.logger('McFenlight', trakt_service_string % ('Success. %s' % trakt_success_line_dict[status], next_update_string))
					else:
						kodi_utils.logger('McFenlight', trakt_service_string % ('Success. No Changes Needed', next_update_string))# 'not needed'
					if status == 'success' and get_setting('mcfenlight.trakt.refresh_widgets', 'false') == 'true':
						kodi_utils.run_plugin({'mode': 'kodi_refresh'})
			except Exception as e: kodi_utils.logger('McFenlight', trakt_service_string % ('Failed', 'The following Error Occured: %s' % str(e)))
			wait_for_abort(wait_time)
		try: del monitor
		except: pass
		try: del player
		except: pass
		return kodi_utils.logger('McFenlight', 'TraktMonitor Service Finished')

class WidgetRefresher:
	def run(self):
		kodi_utils.logger('McFenlight', 'WidgetRefresher Service Starting')
		from time import time
		monitor, player = kodi_utils.kodi_monitor(), kodi_utils.kodi_player()
		wait_for_abort, self.is_playing = monitor.waitForAbort, player.isPlayingVideo
		wait_for_abort(10)
		self.set_next_refresh(time())
		while not monitor.abortRequested():
			try:
				wait_for_abort(10)
				offset = int(get_setting('mcfenlight.widget_refresh_timer', '60'))
				if offset != self.offset:
					self.set_next_refresh(time())
					continue
				if self.condition_check(): continue
				if self.next_refresh < time():
					kodi_utils.logger('McFenlight', 'WidgetRefresher Service - Widgets Refreshed')
					kodi_utils.refresh_widgets()
					self.set_next_refresh(time())
			except: pass
		try: del monitor
		except: pass
		try: del player
		except: pass
		return kodi_utils.logger('McFenlight', 'WidgetRefresher Service Finished')

	def condition_check(self):
		if not self.external(): return True

		if self.next_refresh == None or self.is_playing() or kodi_utils.get_property(pause_services_prop) == 'true': return True
		if kodi_utils.get_property('mcfenlight.window_loaded') == 'true': return True 
		try:
			window_stack = json.loads(kodi_utils.get_property('mcfenlight.window_stack'))
			if window_stack or window_stack == []: return True
		except: pass
		return False

	def set_next_refresh(self, _time):
		self.offset = int(get_setting('mcfenlight.widget_refresh_timer', '60'))
		if self.offset: self.next_refresh = _time + (self.offset*60)
		else: self.next_refresh = None

	def external(self):
		return 'plugin' not in kodi_utils.get_infolabel('Container.PluginName')

class AutoStart:
	def run(self):
		kodi_utils.logger('McFenlight', 'AutoStart Service Starting')
		from modules.settings import auto_start_fenlight
		if auto_start_fenlight(): kodi_utils.run_addon()
		return kodi_utils.logger('McFenlight', 'AutoStart Service Finished')

class AddonXMLCheck:
	def run(self):
		kodi_utils.logger('McFenlight', 'AddonXMLCheck Service Starting')
		from xml.dom.minidom import parse as mdParse
		self.addon_xml = kodi_utils.translate_path('special://home/addons/plugin.video.mcfenlight/addon.xml')
		self.root = mdParse(self.addon_xml)
		self.change_list = []
		self.check_property('reuse_language_invoker', 'reuselanguageinvoker')
		self.change_xml_file()
		return kodi_utils.logger('McFenlight', 'AddonXMLCheck Service Finished')

	def check_property(self, setting, tag_name):
		current_addon_setting = get_setting('mcfenlight.%s' % setting, None)
		if current_addon_setting is None: return
		tag_instance = self.root.getElementsByTagName(tag_name)[0].firstChild
		current_property = tag_instance.data
		if current_property != current_addon_setting:
			tag_instance.data = current_addon_setting
			self.change_list.append(tag_name)

	def change_xml_file(self):
		if not self.change_list: return
		kodi_utils.notification('Refreshing Addon XML. Restarting Addons')
		new_xml = str(self.root.toxml()).replace('<?xml version="1.0" ?>', '')
		with open(self.addon_xml, 'w') as f: f.write(new_xml)
		kodi_utils.logger('McFenlight', 'AddonXMLCheck Service - Change Detected. Restarting Addons')
		kodi_utils.execute_builtin('ActivateWindow(Home)', True)
		kodi_utils.update_local_addons()
		kodi_utils.disable_enable_addon()


class UpdateCheck:
	def run(self):
		if kodi_utils.get_property(firstrun_update_prop) == 'true': return
		kodi_utils.logger('McFenlight', 'UpdateCheck Service Starting')
		from time import time
		from modules.updater import update_check
		from modules.settings import update_action, update_delay
		end_pause = time() + update_delay()
		monitor, player = kodi_utils.kodi_monitor(), kodi_utils.kodi_player()
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		while not monitor.abortRequested():
			while time() < end_pause: wait_for_abort(1)
			while kodi_utils.get_property(pause_services_prop) == 'true' or is_playing(): wait_for_abort(1)
			update_check(update_action())
			break
		kodi_utils.set_property(firstrun_update_prop, 'true')
		try: del monitor
		except: pass
		try: del player
		except: pass
		return kodi_utils.logger('McFenlight', 'UpdateCheck Service Finished')


class SkinSync:
	def run(self):
		kodi_utils.logger('McFenlight', 'SkinSync Service Starting')
		monitor = Monitor()
		if monitor.waitForAbort(45): return
		try:
			from modules.updater import skin_sync
			skin_sync(monitor)
		except: pass
		return kodi_utils.logger('McFenlight', 'SkinSync Service Finished')

class McFenlightMonitor(Monitor):
	def __init__ (self):
		Monitor.__init__(self)
		try:
			from modules.library_scrobbler import LibraryScrobbler
			self.library_scrobbler = LibraryScrobbler()
		except Exception as e:
			self.library_scrobbler = None
			kodi_utils.logger('LibraryScrobbler', str(e))
		self.startServices()

	def startServices(self):
		try: SetAddonConstants().run()
		except Exception as e: kodi_utils.logger('SetAddonConstants', str(e))
		try: DatabaseMaintenance().run()
		except Exception as e: kodi_utils.logger('DatabaseMaintenance', str(e))
		try: SyncSettings().run()
		except Exception as e: kodi_utils.logger('SyncSettings', str(e))
		try: OnUpdateChanges().run()
		except Exception as e: kodi_utils.logger('OnUpdateChanges', str(e))
		try: RepoSourceMigrate().run()
		except Exception as e: kodi_utils.logger('RepoSourceMigrate', str(e))
		try: CocoScrapersCompat().run()
		except Exception as e: kodi_utils.logger('CocoScrapersCompat', str(e))
		try: AddonXMLCheck().run()
		except Exception as e: kodi_utils.logger('AddonXMLCheck', str(e))
		Thread(target=CustomWindowsPrepare().run).start()
		Thread(target=TraktMonitor().run).start()
		Thread(target=WidgetRefresher().run).start()
		Thread(target=UpdateCheck().run).start()
		Thread(target=SkinSync().run).start()
		try: AutoStart().run()
		except Exception as e: kodi_utils.logger('AutoStart', str(e))

	def onNotification(self, sender, method, data):
		if method == 'VideoLibrary.OnUpdate' and self.library_scrobbler:
			self.library_scrobbler.on_library_update(data)
			return
		if method in ('GUI.OnScreensaverActivated', 'System.OnSleep'):
			kodi_utils.set_property(pause_services_prop, 'true')
			kodi_utils.logger('OnNotificationActions', 'PAUSING McFenlight Services Due to Device Sleep')
		elif method in ('GUI.OnScreensaverDeactivated', 'System.OnWake'):
			kodi_utils.clear_property(pause_services_prop)
			kodi_utils.logger('OnNotificationActions', 'UNPAUSING McFenlight Services Due to Device Awake')

kodi_utils.logger('McFenlight', 'Main Monitor Service Starting')
McFenlightMonitor().waitForAbort()
kodi_utils.logger('McFenlight', 'Main Monitor Service Finished')
