# McFenlight self-updater — points at the McFen repo on GitHub Pages (https://amactv.github.io/)
import json
import requests
import shutil
from os import path
from caches.settings_cache import set_setting
from modules.utils import string_alphanum_to_num, unzip
from modules import kodi_utils
logger = kodi_utils.logger

repo_user = 'Amactv'
repo_name = 'amactv.github.io'
repo_base = 'https://amactv.github.io/'  # root user-site: no repo segment in the path
addon_id = 'plugin.video.mcfenlight'

def get_location(insert=''):
	return '%s%s/%s' % (repo_base, addon_id, insert)

def get_versions():
	try:
		result = requests.get(get_location('mcfenlight_version'), timeout=15)
		if result.status_code != 200: return None, None
		online_version = result.text.strip()
		current_version = kodi_utils.addon_version()
		return current_version, online_version
	except: return None, None

def get_changes(online_version=None):
	try:
		if not online_version:
			current_version, online_version = get_versions()
			if not version_check(current_version, online_version): return kodi_utils.ok_dialog(heading='McFenlight Updater',
				text='You are running the current version of McFenlight.[CR][CR]There is no new version changelog to view.')
		kodi_utils.show_busy_dialog()
		result = requests.get(get_location('mcfenlight_changes'), timeout=15)
		kodi_utils.hide_busy_dialog()
		if result.status_code != 200: return kodi_utils.notification('Error', icon=kodi_utils.get_icon('downloads'))
		changes = result.text
		return kodi_utils.show_text('New Online Release (v.%s) Changelog' % online_version, text=changes, font_size='large')
	except:
		kodi_utils.hide_busy_dialog()
		return kodi_utils.notification('Error', icon=kodi_utils.get_icon('downloads'))

def _version_key(version):
	import re
	return [int(x) for x in re.findall(r'\d+', version or '')]

def version_check(current_version, online_version):
	# Only offer NEWER releases (was "!=", which offered downgrades to anyone ahead of the repo)
	return _version_key(online_version) > _version_key(current_version)

def _fetch_first_changelog_line(online_version):
	"""Return the first bullet point from the online changelog, stripped of Kodi tags."""
	import re
	try:
		result = requests.get(get_location('mcfenlight_changes'), timeout=15)
		if result.status_code != 200: return ''
		for line in result.text.splitlines():
			line = re.sub(r'\[/?(?:COLOR[^\]]*|B|I|CR)\]', '', line).strip()
			if line.startswith('- '):
				return line[2:]
	except: pass
	return ''

def update_check(action=4):
	if action == 3: return
	current_version, online_version = get_versions()
	if not current_version or not online_version: return
	if not version_check(current_version, online_version):
		if action == 4: return kodi_utils.ok_dialog(heading='McFenlight Updater',
			text='Installed Version: [B]%s[/B][CR]Online Version: [B]%s[/B][CR][CR][B]No Update Available[/B]' % (current_version, online_version))
		return
	if action == 2: return kodi_utils.notification('McFenlight Update Available', icon=kodi_utils.get_icon('downloads'))
	if action == 1: kodi_utils.notification('McFenlight Update Occurring', icon=kodi_utils.get_icon('downloads'))
	if action in (0, 4):
		kodi_utils.show_busy_dialog()
		first_line = _fetch_first_changelog_line(online_version)
		kodi_utils.hide_busy_dialog()
		text = '[B]v%s[/B] is available[CR][CR]%s[CR][CR]Install now?' % (online_version, first_line)
		if not kodi_utils.confirm_dialog(heading='McFenlight Update', text=text, ok_label='Update', cancel_label='Skip'):
			return
	return update_addon(online_version, action, show_after_action=False)

def rollback_check():
	current_version = get_versions()[0]
	url = 'https://api.github.com/repos/%s/%s/contents/%s' % (repo_user, repo_name, addon_id)
	kodi_utils.show_busy_dialog()
	results = requests.get(url, timeout=15)
	kodi_utils.hide_busy_dialog()
	if results.status_code != 200: return kodi_utils.ok_dialog(heading='McFenlight Updater', text='Error rolling back.[CR]Please install rollback manually')
	results = results.json()
	results = [i['name'].split('-')[1].replace('.zip', '') for i in results if addon_id in i['name'] and i['name'].endswith('.zip') \
				and not i['name'].split('-')[1].replace('.zip', '') == current_version]
	if not results: return kodi_utils.ok_dialog(heading='McFenlight Updater', text='No previous versions found.[CR]Please install rollback manually')
	results.sort(reverse=True)
	list_items = [{'line1': item, 'icon': kodi_utils.get_icon('downloads')} for item in results]
	kwargs = {'items': json.dumps(list_items), 'heading': 'Choose Rollback Version'}
	rollback_version = kodi_utils.select_dialog(results, **kwargs)
	if rollback_version == None: return
	if not kodi_utils.confirm_dialog(heading='McFenlight Updater',
		text='Are you sure?[CR]Version [B]%s[/B] will overwrite your current installed version.[CR]McFenlight will set your update action to [B]OFF[/B] if rollback is successful' \
		% rollback_version): return
	update_addon(rollback_version, 5)

def _verify_zip_integrity(zip_location, new_version):
	# H2: verify the downloaded zip against the SHA-256 published with the release before
	# rmtree/unzip. If the repo hasn't published a hash yet, fall back to allowing the
	# update (logged) so older releases still install; enforced once the hash is published.
	import hashlib
	try:
		expected = requests.get(get_location('%s-%s.zip.sha256' % (addon_id, new_version)), timeout=15)
		if expected.status_code != 200:
			expected = requests.get(get_location('mcfenlight_sha256'), timeout=15)
		if expected.status_code != 200:
			logger('McFenlight.updater', 'no published SHA-256 - skipping integrity check')
			return True
		expected_hash = expected.text.strip().split()[0].lower()
		if len(expected_hash) != 64: return True
		h = hashlib.sha256()
		with open(zip_location, 'rb') as f:
			for chunk in iter(lambda: f.read(65536), b''): h.update(chunk)
		actual = h.hexdigest().lower()
		if actual == expected_hash: return True
		logger('McFenlight.updater', 'SHA-256 mismatch expected=%s actual=%s' % (expected_hash, actual))
		return False
	except Exception as e:
		logger('McFenlight.updater', 'integrity check error: %s' % str(e))
		return True

def update_addon(new_version, action, show_after_action=True):
	kodi_utils.close_all_dialog()
	kodi_utils.execute_builtin('ActivateWindow(Home)', True)
	kodi_utils.notification('McFenlight Performing Rollback' if action == 5 else 'McFenlight Performing Update', icon=kodi_utils.get_icon('downloads'))
	zip_name = '%s-%s.zip' % (addon_id, new_version)
	url = get_location(zip_name)
	kodi_utils.show_busy_dialog()
	result = requests.get(url, stream=True, timeout=60)
	kodi_utils.hide_busy_dialog()
	if result.status_code != 200: return kodi_utils.ok_dialog(heading='McFenlight Updater', text='Error Updating.[CR]Please install new update manually')
	zip_location = path.join(kodi_utils.translate_path('special://home/addons/packages/'), zip_name)
	with open(zip_location, 'wb') as f: shutil.copyfileobj(result.raw, f)
	if not _verify_zip_integrity(zip_location, new_version):
		kodi_utils.delete_file(zip_location)
		return kodi_utils.ok_dialog(heading='McFenlight Updater', text='Update aborted.[CR]Downloaded file failed its integrity check.[CR]Please install manually if this persists.')
	shutil.rmtree(path.join(kodi_utils.translate_path('special://home/addons/'), addon_id))
	success = unzip(zip_location, kodi_utils.translate_path('special://home/addons/'), kodi_utils.translate_path('special://home/addons/%s/' % addon_id))
	kodi_utils.delete_file(zip_location)
	if not success: return kodi_utils.ok_dialog(heading='McFenlight Updater', text='Error Updating.[CR]Please install new update manually')
	if action == 5:
		set_setting('update.action', '3')
		kodi_utils.ok_dialog(heading='McFenlight Updater', text='[CR]Success.[CR]McFenlight rolled back to version [B]%s[/B]' % new_version)
	elif action in (0, 4):
		if show_after_action:
			if kodi_utils.confirm_dialog(heading='McFenlight Updater', text='[CR]Success.[CR]McFenlight updated to version [B]%s[/B]' % new_version,
										ok_label='Changelog', cancel_label='Exit', default_control=10) != False:
				kodi_utils.show_text('Changelog', file=kodi_utils.translate_path('special://home/addons/%s/resources/text/changelog.txt' % addon_id), font_size='large')
		else:
			kodi_utils.ok_dialog(heading='McFenlight Updater', text='[CR]Success.[CR]McFenlight updated to version [B]%s[/B]' % new_version)
	kodi_utils.clear_addon_icon_texture_cache()
	kodi_utils.update_local_addons()
	kodi_utils.disable_enable_addon()
	kodi_utils.update_kodi_addons_db()
	kodi_utils.refresh_widgets()

# ---------------------------------------------------------------- Confluence (McFen Edition) skin delivery
# Same skin id as stock Confluence, so swapping files + ReloadSkin applies it with no "Keep this change?" prompt
# and keeps every user's Confluence skin settings. Published at <repo>/skin.confluence/ (not in addons.xml, so
# Kodi's repo browser never offers it). Fail-closed: no published SHA-256 -> no install.
skin_id = 'skin.confluence'
skin_min_kodi = 21  # built on Confluence 5.0.9 (xbmc.gui 5.17 = Kodi 21 Omega)

def skin_location(insert=''):
	return '%s%s/%s' % (repo_base, skin_id, insert)

def _installed_skin_version(skin_dir):
	import re
	try:
		with open(path.join(skin_dir, 'addon.xml'), encoding='utf-8') as f:
			return re.search(r'<addon[^>]+id="%s"[^>]+version="([^"]+)"' % skin_id, f.read()).group(1)
	except: return None

def _sha256(file_path):
	import hashlib
	h = hashlib.sha256()
	with open(file_path, 'rb') as f:
		for chunk in iter(lambda: f.read(65536), b''): h.update(chunk)
	return h.hexdigest().lower()

def skin_sync(monitor=None):
	import xbmc
	log = lambda msg: logger('McFenlight.skin', msg)
	try:
		if int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0]) < skin_min_kodi: return
		addons_dir = kodi_utils.translate_path('special://home/addons/')
		skin_dir = path.join(addons_dir, skin_id)
		installed = _installed_skin_version(skin_dir)
		if not installed: return  # only devices that already have Confluence
		result = requests.get(skin_location('mcfen_skin_version'), timeout=15)
		if result.status_code != 200: return
		online = result.text.strip()
		if _version_key(online) <= _version_key(installed): return
		log('Confluence %s -> %s available' % (installed, online))
		zip_name = '%s-%s.zip' % (skin_id, online)
		expected = requests.get(skin_location(zip_name + '.sha256'), timeout=15)
		if expected.status_code != 200: return log('no published SHA-256 - not installing')
		expected_hash = expected.text.strip().split()[0].lower()
		result = requests.get(skin_location(zip_name), stream=True, timeout=120)
		if result.status_code != 200: return log('download failed: HTTP %s' % result.status_code)
		packages = kodi_utils.translate_path('special://home/addons/packages/')
		zip_location = path.join(packages, zip_name)
		with open(zip_location, 'wb') as f: shutil.copyfileobj(result.raw, f)
		if _sha256(zip_location) != expected_hash:
			kodi_utils.delete_file(zip_location)
			return log('SHA-256 mismatch - not installing')
		stage = path.join(packages, 'mcfen_skin_stage')
		if path.exists(stage): shutil.rmtree(stage)
		from zipfile import ZipFile
		with ZipFile(zip_location) as zf: zf.extractall(stage)
		kodi_utils.delete_file(zip_location)
		new_dir = path.join(stage, skin_id)
		if _installed_skin_version(new_dir) != online:
			shutil.rmtree(stage)
			return log('staged skin version mismatch - not installing')
		# never swap the skin under someone mid-film: wait until nothing is playing
		player = xbmc.Player()
		while player.isPlaying():
			if monitor and monitor.waitForAbort(30): return
			elif not monitor: xbmc.sleep(30000)
		backups = path.join(kodi_utils.translate_path('special://profile/addon_data/%s/' % addon_id), 'skin_backup')
		backup = path.join(backups, '%s-%s' % (skin_id, installed))
		if not path.exists(backups):
			import os
			os.makedirs(backups)
		if path.exists(backup): shutil.rmtree(backup)
		shutil.move(skin_dir, backup)
		try: shutil.move(new_dir, skin_dir)
		except Exception as e:
			shutil.move(backup, skin_dir)
			return log('swap failed, restored %s: %s' % (installed, e))
		shutil.rmtree(stage, ignore_errors=True)
		kodi_utils.execute_builtin('UpdateLocalAddons', True)
		xbmc.sleep(3000)
		if xbmc.getSkinDir() == skin_id: kodi_utils.execute_builtin('ReloadSkin()')
		log('installed Confluence (McFen Edition) %s (backup of %s kept)' % (online, installed))
	except Exception as e:
		log('skin sync error: %s' % e)

# ---------------------------------------------------------------- Companion add-on delivery
# Kodi on the fleet is set to "Notify" for add-on updates (the setup wizard does that so this updater is the only thing
# that installs McFen), which means the McFen repository and the other companion add-ons never update by themselves.
# The release publishes <repo>/mcfen_companions.json (version + SHA-256 for each companion zip) and this keeps every
# companion that is ALREADY installed up to date: newer-only, fail-closed on a missing/mismatched hash, never while
# something is playing, previous version backed up to addon_data. It never installs a companion that isn't there.
companion_ids = ('repository.mcfenlight', 'script.mcfenlight.setup', 'service.mcfenlight.backgrounds', 'script.mcfenlight.emby')
companion_min_kodi = 21  # repository.mcfenlight 1.0.4+ requires xbmc.addon 21

def _installed_addon_version(addon_dir, _addon_id):
	import re
	try:
		with open(path.join(addon_dir, 'addon.xml'), encoding='utf-8') as f:
			return re.search(r'<addon[^>]+id="%s"[^>]+version="([^"]+)"' % re.escape(_addon_id), f.read()).group(1)
	except: return None

def _update_companion(_addon_id, info, monitor, log):
	import os
	import xbmc
	addons_dir = kodi_utils.translate_path('special://home/addons/')
	addon_dir = path.join(addons_dir, _addon_id)
	installed = _installed_addon_version(addon_dir, _addon_id)
	if not installed: return False  # only devices that already have it
	online = str(info.get('version') or '').strip()
	if not online or _version_key(online) <= _version_key(installed): return False
	expected_hash = str(info.get('sha256') or '').strip().lower()
	zip_name = '%s-%s.zip' % (_addon_id, online)
	if len(expected_hash) != 64: return log('%s %s: no published SHA-256 - not installing' % (_addon_id, online))
	log('%s %s -> %s available' % (_addon_id, installed, online))
	result = requests.get('%s%s/%s' % (repo_base, _addon_id, zip_name), stream=True, timeout=60)
	if result.status_code != 200: return log('%s: download failed: HTTP %s' % (_addon_id, result.status_code))
	packages = kodi_utils.translate_path('special://home/addons/packages/')
	zip_location = path.join(packages, zip_name)
	with open(zip_location, 'wb') as f: shutil.copyfileobj(result.raw, f)
	if _sha256(zip_location) != expected_hash:
		kodi_utils.delete_file(zip_location)
		return log('%s: SHA-256 mismatch - not installing' % _addon_id)
	stage = path.join(packages, 'mcfen_companion_stage')
	if path.exists(stage): shutil.rmtree(stage)
	from zipfile import ZipFile
	with ZipFile(zip_location) as zf:
		if any(not n.startswith(_addon_id + '/') for n in zf.namelist()):
			kodi_utils.delete_file(zip_location)
			return log('%s: unexpected zip layout - not installing' % _addon_id)
		zf.extractall(stage)
	kodi_utils.delete_file(zip_location)
	new_dir = path.join(stage, _addon_id)
	if _installed_addon_version(new_dir, _addon_id) != online:
		shutil.rmtree(stage, ignore_errors=True)
		return log('%s: staged version mismatch - not installing' % _addon_id)
	# never swap add-ons under someone mid-film: wait until nothing is playing
	player = xbmc.Player()
	while player.isPlaying():
		if monitor and monitor.waitForAbort(30):
			shutil.rmtree(stage, ignore_errors=True)
			return False
		elif not monitor: xbmc.sleep(30000)
	backups = path.join(kodi_utils.translate_path('special://profile/addon_data/%s/' % addon_id), 'companion_backup')
	if not path.exists(backups): os.makedirs(backups)
	backup = path.join(backups, '%s-%s' % (_addon_id, installed))
	if path.exists(backup): shutil.rmtree(backup)
	# os.rename only: it either moves the whole folder or fails having changed nothing (no copy-then-delete fallback)
	try: os.rename(addon_dir, backup)
	except Exception as e:
		shutil.rmtree(stage, ignore_errors=True)
		return log('%s: could not move current version aside, left unchanged: %s' % (_addon_id, e))
	try: os.rename(new_dir, addon_dir)
	except Exception as e:
		os.rename(backup, addon_dir)
		shutil.rmtree(stage, ignore_errors=True)
		return log('%s: swap failed, restored %s: %s' % (_addon_id, installed, e))
	shutil.rmtree(stage, ignore_errors=True)
	log('installed %s %s (backup of %s kept)' % (_addon_id, online, installed))
	return True

def companion_sync(monitor=None):
	import xbmc
	log = lambda msg: logger('McFenlight.companions', msg)
	try:
		if int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0]) < companion_min_kodi: return
		result = requests.get('%smcfen_companions.json' % repo_base, timeout=15)
		if result.status_code != 200: return
		manifest = result.json()
		updated = []
		for _addon_id in companion_ids:
			info = manifest.get(_addon_id)
			if not isinstance(info, dict): continue
			try:
				if _update_companion(_addon_id, info, monitor, log) is True: updated.append(_addon_id)
			except Exception as e: log('%s: update error: %s' % (_addon_id, e))
			if monitor and monitor.abortRequested(): return
		if not updated: return
		kodi_utils.execute_builtin('UpdateLocalAddons', True)
		xbmc.sleep(3000)
		log('companions updated: %s' % ', '.join(updated))
	except Exception as e:
		log('companion sync error: %s' % e)
